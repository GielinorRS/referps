package com.ruse.model.input;

import com.ruse.world.entity.impl.player.Player;

public class Input {

	public void handleSyntax(Player player, String text) {

	}

	public void handleAmount(Player player, int amount) {

	}

	public void handleLongAmount(Player player, long amount) {

	}
}
