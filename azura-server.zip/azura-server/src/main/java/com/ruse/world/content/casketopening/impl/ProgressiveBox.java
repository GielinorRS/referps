package com.ruse.world.content.casketopening.impl;

import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class ProgressiveBox {

    public static Box[] loot = { //
            new Box(671, 1, 33, true),
            new Box(4411, 1, 33, true),
            new Box(14415, 1, 33, true),
            new Box(14395, 1, 33, true),
            new Box(14405, 1, 33, true),
            new Box(672, 1, 33, true),
            new Box(673, 1, 33, true),
            new Box(677, 1, 33, true),
            new Box(678, 1, 33, true),
            new Box(679, 1, 33, true),
            new Box(22075, 1, 33, true),
            new Box(19471, 1, 33, true),
            new Box(19470, 1, 33, true),
            new Box(19469, 1, 33, true),
            new Box(666, 1, 33, true),
            new Box(15424, 1, 33, true),
            new Box(674, 1, 33, true),
            new Box(22078, 1, 33, true),
            new Box(4369, 1, 33, true),
            new Box(15877, 1, 33, true),
            new Box(16269, 1, 33, true),
            new Box(15943, 1, 33, true),
            new Box(675, 1, 33, true),
            new Box(702, 1, 33, true),
            new Box(700, 1, 33, true),
            new Box(701, 1, 33, true),
            new Box(17708, 1, 33, true),
            new Box(5095, 1, 33, true),
            new Box(19140, 1, 33, true),
            new Box(19139, 1, 33, true),
            new Box(19138, 1, 33, true),
            new Box(15922, 1, 33, true),
            new Box(16021, 1, 33, true),
            new Box(15933, 1, 33, true),
            new Box(19944, 1, 33, true),
            new Box(703, 1, 33, true),
            new Box(704, 1, 33, true),
            new Box(705, 1, 33, true),
            new Box(19946, 1, 33, true),
    };

}
