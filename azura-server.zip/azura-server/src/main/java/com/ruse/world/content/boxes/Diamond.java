package com.ruse.world.content.boxes;

public class Diamond {


    public static int[] common = new int[]{10934,10935,3578,20489,15288,19886};
    public static int[] uncommon = new int[]{18818,18881,18883,19810,3578};
    public static int[] rare = new int[]{17011,12535,5012,20400,12630,7995};
}
