package com.ruse.world.content.boxes;

public class Ruby {

    public static int[] common = new int[]{10934,10935,3578,20489,15288,19886};
    public static int[] uncommon = new int[]{18818,18881,18883};
    public static int[] rare = new int[]{19810,3578};
}
