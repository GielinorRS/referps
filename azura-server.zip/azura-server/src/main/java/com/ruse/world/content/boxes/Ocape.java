package com.ruse.world.content.boxes;

public class Ocape {

    public static int[] rare = new int[]{7995, 10934};

}
