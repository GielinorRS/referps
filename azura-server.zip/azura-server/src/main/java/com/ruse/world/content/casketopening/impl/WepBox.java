package com.ruse.world.content.casketopening.impl;

import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class WepBox {

    public static Box[] loot = { //20549, 20173, 8809, 8834, 8835, 8860, 8861, 8862, 15830, 3318, 15418
            new Box(ItemDefinition.COIN_ID, 1000000, 100),
            new Box(14915, 1, 50),
            new Box(14919, 1, 50),
            new Box(14924, 1, 50),
            new Box(22084, 1, 20),
            new Box(22083, 1, 20),
            new Box(22092, 1, 20),
            new Box(20549, 1, 10),
            new Box(20173, 1, 10),
            new Box(8809, 1, 10),
            //new Box(8087, 1, 5),
            // new Box(8088, 1, 5),
            // new Box(8089, 1, 5),
    };

}
