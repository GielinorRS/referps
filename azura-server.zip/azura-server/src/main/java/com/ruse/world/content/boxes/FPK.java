package com.ruse.world.content.boxes;


import com.ruse.world.content.casketopening.Box;

public class FPK {

	public static Box[] LOOT = {

			new Box(11846, 1, 100), // ORBS
			new Box(11848, 1, 30), // ORBS
			new Box(11850, 1, 20), // ORBS
			new Box(11852, 1, 10),// ORBS
			new Box(11854, 1, 5), // ORBS PACK (5K)
			new Box(11856, 1, 5), // ORBS PACK (5K)
			new Box(3907, 1, 10), //SUPER BOX
			new Box(8803, 1, 5), //EXTREME BOX
			new Box(8804, 1, 1), //GRAND BOX
			new Box(8805, 1, 10), //SUPER BOX
			new Box(20173, 1, 5), //EXTREME BOX
			new Box(8806, 1, 1), //GRAND BOX			
			new Box(8807, 1, 5), //EXTREME BOX
			new Box(8808, 1, 1), //GRAND BOX
			new Box(8809, 1, 1), //GRAND BOX
			new Box(19114, 1, 5), // RAIDS BOX
			new Box(19115, 1, 3), // RAIDS BOX
			new Box(19116, 1, 1), // RAIDS BOX 
			new Box(15288, 1, 5), // RAIDS BOX
			new Box(15289, 1, 3), // RAIDS BOX
			new Box(15290, 1, 1), // RAIDS BOX 
			new Box(10946, 1, 5), // RAIDS BOX
			new Box(20488, 1, 3), // RAIDS BOX
			new Box(11310, 1, 1), // RAIDS BOX 

	};
}