package com.ruse.world.content.boxes;

public class OP {

    public static int[] common = new int[]{8800, 8803, 8806, 8801, 8804, 8807, 8802, 8805, 8808, 20549, 20173, 8809,
            10946, 10946, 10946,};
    public static int[] uncommon = new int[]{8326, 8330, 8323, 8327, 8331, 8324, 8328, 8332, 8325, 22084, 22083, 22092,
            10946, 10942};
    public static int[] rare = new int[]{18753, 18749, 18631, 18752, 18748, 18637, 18751, 18631, 18623, 18750, 18636,
            18629, 19886, 4446, 6769, 10942};
}
