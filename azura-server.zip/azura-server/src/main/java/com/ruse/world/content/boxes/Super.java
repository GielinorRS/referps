package com.ruse.world.content.boxes;

import com.ruse.model.definitions.ItemDefinition;

public class Super {

    public static int[] common = new int[]{ItemDefinition.TOKEN_ID, 989, 4888, 18332, 14377, 13902, 13899, 11730};
    public static int[] uncommon = new int[]{13922, 13952, 13940, 13910, 13946, 13934, 13916, 13949, 13937, 14915,
            14919, 14924};
    public static int[] rare = new int[]{13922, 13952, 13940, 13910, 13946, 13934, 13916, 13949, 13937, 14915,
            14919, 14924};
}
