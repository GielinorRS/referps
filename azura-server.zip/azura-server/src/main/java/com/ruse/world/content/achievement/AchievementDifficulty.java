package com.ruse.world.content.achievement;

/**
 * @author Leviticus http://www.rune-server.org/members/leviticus
 * @date May, 9, 2018
 */
public enum AchievementDifficulty {

    EASY, MEDIUM, HARD, DAILY

}
