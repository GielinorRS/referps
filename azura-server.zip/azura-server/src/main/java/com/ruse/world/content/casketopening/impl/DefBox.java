package com.ruse.world.content.casketopening.impl;

import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class DefBox {

    public static Box[] loot = { //
            new Box(ItemDefinition.COIN_ID, 1000000, 100),
            new Box(23134, 1, 33, true),
            new Box(23135, 1, 33, true),
            new Box(23136, 1, 33, true),
            new Box(23137, 1, 33, true),
            new Box(23138, 1, 33, true),
            new Box(23021, 1, 33, true),
            new Box(23022, 1, 33, true),
            new Box(23023, 1, 33, true),
            new Box(23024, 1, 33, true),
            new Box(23025, 1, 33, true),
            new Box(23027, 1, 33, true),
            new Box(23028, 1, 33, true),
            new Box(23029, 1, 33, true),
            new Box(23030, 1, 33, true),
            new Box(23031, 1, 33, true),
            new Box(23032, 1, 33, true),
            new Box(23034, 1, 33, true),
            new Box(23035, 1, 33, true),
            new Box(23036, 1, 33, true),
            new Box(23037, 1, 33, true),
            new Box(23038, 1, 33, true),
            new Box(23096, 1, 33, true),
            new Box(23097, 1, 33, true),
            new Box(23098, 1, 33, true),
    };

}
