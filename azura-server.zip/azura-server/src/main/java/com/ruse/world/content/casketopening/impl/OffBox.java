package com.ruse.world.content.casketopening.impl;

import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class OffBox {

    public static Box[] loot = { //
            new Box(ItemDefinition.COIN_ID, 1000000, 100),
            new Box(23033, 1, 10, true),
            new Box(23026, 1, 10, true),
            new Box(23039, 1, 10, true),
            new Box(23096, 1, 10, true),
            new Box(23097, 1, 10, true),
            new Box(23098, 1, 10, true),
            new Box(23165, 1, 5, true),
            new Box(23166, 1, 5, true),
            new Box(23167, 1, 5, true),
            new Box(23168, 1, 5, true),
            new Box(23169, 1, 5, true),
            new Box(23170, 1, 5, true),
    };

}
