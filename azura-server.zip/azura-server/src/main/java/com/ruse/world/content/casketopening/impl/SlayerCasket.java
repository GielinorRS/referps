package com.ruse.world.content.casketopening.impl;

import com.ruse.world.content.casketopening.Box;

public class SlayerCasket {

    public static Box[] loot = { //
            new Box(437, 100,70, 100D),
            new Box(439, 70, 100, 100D),
            new Box(452, 30, 45, 100D ),
            new Box(450, 45, 60, 100D),
            new Box(454, 100, 150, 100D),
            new Box(448, 60, 75, 100D),

            new Box(318, 70, 100, 100D),
            new Box(336, 70, 100, 100D),
            new Box(360, 50, 75, 100D),
            new Box(372, 30, 40, 100D),
            new Box(384, 20, 30, 100D),
            new Box(390, 20, 30, 100D),
            new Box(17816, 20, 30, 100D),

            new Box(1512, 85, 100, 100D),
            new Box(1522, 70, 80, 100D),
            new Box(1520, 75, 90, 100D),
            new Box(1518, 60, 70, 100D),
            new Box(1516, 50, 60, 100D),
            new Box(1514, 40, 50, 100D),

            new Box(1624, 40, 55, 100D),
            new Box(1622, 30, 45, 100D),
            new Box(1620, 25, 40, 100D),
            new Box(1618, 25, 40, 100D),
            new Box(1632, 25, 35, 100D),

            new Box(200, 10, 20, 100D),
            new Box(202, 10, 20, 100D),
            new Box(204, 10, 20, 100D),
            new Box(206, 10, 15, 100D),
            new Box(208, 10, 12, 100D),
            new Box(3050, 9, 11, 100D),
            new Box(210, 9, 11, 100D),
            new Box(212, 9, 10, 100D),
            new Box(214, 8, 10, 100D),
            new Box(3052, 6, 8, 100D),
            new Box(216, 6, 8, 100D),
            new Box(2486, 5, 7, 100D),
            new Box(218, 4, 6, 100D),
            new Box(220, 4, 5, 100D),

            new Box(1437, 200, 220, 100D),
            new Box(7937, 150, 175, 100D),

            new Box(5291, 12, 20, 100D),
            new Box(5292, 12, 17, 100D),
            new Box(5293, 12, 15, 100D),
            new Box(5294, 10, 12, 100D),
            new Box(5295, 7, 12, 100D),
            new Box(5296, 7, 10, 100D),
            new Box(5297, 3, 5, 100D),
            new Box(5298, 3, 5, 100D),
            new Box(5299, 3, 5, 100D),
            new Box(5300, 1, 2, 100D),
            new Box(5301, 1, 2, 100D),
            new Box(5302, 1, 2, 100D),
            new Box(5303, 1, 100D),
            new Box(5304, 1, 100D),

    };

}
