package com.ruse.world.content.boxes;

public class Raids2 {

    public static int[] common = new int[]{6927, 6928, 6929, 6930, 6931, 6932, 6933, 6935, 6936, 22077, 19136, 6936,15289,15290};
    public static int[] uncommon = new int[]{8326,8327,8328,8330,8331,8332,8323,8324,8325,10025,19116,19115,19114,20488,15288};
    public static int[] rare = new int[]{5012, 12535, 17011, 4446, 19886, 1486, 17700, 20489, 10025, 455, 10946, 18419, 18418, 18416, 6500, 18719, 7587, 12608};
}
