package com.ruse.world.content.casketopening.impl;

import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class RareBox {

    public static Box[] loot = { //
            new Box(ItemDefinition.COIN_ID, 1000000, 100),
            new Box(1038, 1, 0.5, true),
            new Box(1040, 1, 0.5, true),
            new Box(1042, 1, 0.5, true),
            new Box(1044, 1, 0.5, true),
            new Box(1046, 1, 0.5, true),
            new Box(1048, 1, 0.5, true),
            new Box(1050, 1, 0.5, true),
            new Box(1053, 1, 1, true),
            new Box(1055, 1, 1, true),
            new Box(1057, 1, 1, true),
            new Box(22041, 1, 0.1, true),
    };

}
