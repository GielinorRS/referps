package com.ruse.world.content.boxes;

public class DRPetBox {
    public static  int petRewards[][] = { { 1563, 1564, 1562, 12514, 12512, 12522, 12518 }, // Uncommon, 0
            { 1563, 1564, 1562, 12514, 12512, 12522, 12518 }, // Rare, 1
            { 1563, 1564, 1562, 12514, 12512, 12522, 12518 }, // Epic, 2
            { 1563, 1564, 1562, 12514, 12512, 12522, 12518 } // Legendary, 3
    };
}
