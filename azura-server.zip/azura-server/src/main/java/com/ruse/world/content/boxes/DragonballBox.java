package com.ruse.world.content.boxes;

public class DragonballBox {
    public static int[] common1 = new int[]{2025, 6199, 18686, 18799, 5095, 15290, 7956};
    public static int[] uncommon1 = new int[]{14827, 14818, 14820, 21060, 11195, 10946, 962, 19116, 15418, 17291, 3318,
            19136, 10887};
    public static int[] rare1 = new int[]{17546, 15289, 6769, 11763, 11764, 11765, 9481, 9482, 9483, 9478, 9479, 9480};
}
