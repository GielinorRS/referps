package com.ruse.world.content.boxes;

public class Launch {

    public static int[] common = new int[]{8326, 8330, 8323, 8327, 8331, 8324, 8328, 8332, 8325, 22084, 22083, 22092,
            10946, 10942,15288};
    public static int[] uncommon = new int[]{18753, 18749, 18631, 18752, 18748, 18637, 18751, 18638, 18623, 18750, 18636,
            18629, 4446, 6769, 10942};
    public static int[] rare = new int[]{8253,19886, 8087, 8088, 8089, 10947,12608,10934,3578};
}
