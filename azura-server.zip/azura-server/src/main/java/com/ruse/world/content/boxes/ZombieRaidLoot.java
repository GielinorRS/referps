package com.ruse.world.content.boxes;


import com.ruse.model.definitions.ItemDefinition;
import com.ruse.world.content.casketopening.Box;

public class ZombieRaidLoot {

	public static Box[] LOOT = {

			//new Box(788, 1, 5,100), // ORBS
			new Box(677, 1, 0.3D), // ORBS
			new Box(678, 1, 0.3D), // ORBS
			new Box(679, 1, 0.3D),// ORBS
			new Box(995, 250000, 5000000, 100D),
			new Box(15358, 1, 25),
			new Box(15359, 1, 25),
			new Box(23174, 1, 25),
			//new Box(19115, 1, 5), //EXTREME BOX
			//new Box(19114, 1, 1), //GRAND BOX

			//zombie
			//new Box(18404, 1, 30), // RAIDS BOX
			//new Box(18404, 2, 3), // RAIDS BOX
		//	new Box(18404, 3, 1), // RAIDS BOX

	};

}
