package com.ruse.world.content.boxes;

public class PVMBox {
    public final static int ITEM_ID = 7956;
   public static int[] commonpvm = new int[] { 4716, 4720, 4718, 4722, 4708, 4712, 4714, 4710, 4732, 4736, 4738, 4734, 4753,
            4757, 4759, 4755, 4745, 4749, 4751, 4747, 290 };
    public static int[] uncommonpvm = new int[] { 11852, 11854, 11856, 11846, 11848 };
    public static int[] rarepvm = new int[] { 4151, 11235, 15486, 13262, 18353, 11732, 6585, 6737, 7462, };
}
