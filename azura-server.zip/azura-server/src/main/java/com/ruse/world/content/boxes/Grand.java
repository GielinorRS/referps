package com.ruse.world.content.boxes;

public class Grand {

    public static int[] common = new int[]{13736, 13744, 13742, 13740, 6293, 18754, 11694, 11696, 11698, 11700, 1038,
            1040, 1042, 1044, 1046, 1048};
    public static int[] uncommon = new int[]{20549, 20173, 8809, 8834, 8835, 8860, 8861, 8862, 15830, 3318, 15418};
    public static int[] rare = new int[]{8326, 8330, 8323, 8327, 8331, 8324, 8328, 8332, 8325, 22084, 22083, 22092,
            10946, 10942, 6769,};
}
