package com.ruse;

import com.ruse.model.Item;
import com.ruse.model.Position;
import com.ruse.net.security.ConnectionHandler;

import java.math.BigInteger;

public class GameSettings {

    public static final int GAME_VERSION = 3;
    public static final int GAME_PORT = 9420;
    public static boolean LOCALHOST = false;
    public static boolean BOGO = false;
    public static boolean B2GO = false;

    // Beta variable, allows certain functionality.. DISABLE WHEN LIVE
    public static boolean BETA_ENABLED = false;

    /*
     * Bunch of variables for the Global Events
     */
    public static boolean DOUBLE_VOTE = false;
    public static boolean DOUBLE_DROP = false;
    public static boolean DOUBLE_SKILL_EXP = false;
    public static boolean DOUBLE_KOL = false;
    public static boolean DOUBLE_SLAYER = false;

    public static String broadcastMessage = null;
    public static int broadcastTime = 0;

    public static final String[] CLIENT_HASH = { "d41d8cd98f00b204e9800998ecf8427e" };

    public static final String RSPS_NAME = "Aspect";
    public static final String BCRYPT_EXAMPLE_SALT = "$2a$09$kCPIaYJ6vJmzJM/zq8vuSO";
    /**
     * WEB URLS
     */
    public static final String DomainUrl = "https://aspect-rsps.com";
    public static final String ForumUrl = "https://aspect-rsps.com";
    public static final String showthreadx = "-x";
    public static final String UpdateUrl = "https://discord.gg/aspectps";
    public static final String StoreUrl = "https://aspect-rsps.com/store";
    public static final String sprad = "https://www.youtube.com/channel/UCL5_jd65woKzjKfXhbBIuJQ";
    public static final String morgen = "https://www.youtube.com/channel/UCIFSpy1z7aMWZnQJlDF1Wcg";
    public static final String effigy = "https://www.youtube.com/channel/UCR-GGPuNM7V51JYWVbcDURQ";
    public static final String wr3cked = "https://www.youtube.com/channel/UCNm7R0y8KN8kSn3yVn04pkg";
    public static final String ipkmaxjr = "https://www.youtube.com/channel/UCybjJ14mJjeeQaa7HqkyEzg";
    
    public static final String Didy = "https://www.youtube.com/channel/UC6ag3g4fFug0ZmXOeDpHnTw";
    public static final String FpkMerk = "https://www.youtube.com/channel/UCeVDQGzCI3dxp8NAT_YBIkQ/videos";
    public static final String ogrsps = "https://www.youtube.com/user/HippHopp1100";
    public static final String Stable = "https://www.youtube.com/channel/UCIFSpy1z7aMWZnQJlDF1Wcg";
    public static final String ZachTX = "https://www.youtube.com/user/SwailyRS/";
    public static final String Khalil = "https://www.youtube.com/channel/UCMc0hysuD8NsUTspX8MwFtw";
    public static final String VoteUrl = "https://aspect-rsps.com/vote";
    public static final String PriceList = "https://discord.gg/aspectps";
    public static final String HiscoreUrl = "https://discord.gg/aspectps";
    public static final String ReportUrl = "https://discord.gg/aspectps";
    public static final String RuleUrl = "https://discord.gg/aspectps";
    public static final String CommandsUrl =  "https://discord.gg/aspectps";
    public static final String RankFeaturesUrl = "https://discord.gg/aspectps";
    public static final String WikiaUrl = "https://discord.gg/aspectps";
    public static final String IronManModesUrl = "https://discord.gg/aspectps";
    public static final String HexUrl = "www.colorpicker.com";
    public static final String DiscordUrl = "https://discord.gg/aspectps";
    public static final String ThreadUrl = "https://discord.gg/aspectps";
    public static final String RickRoll = "https://discord.gg/aspectps";
    public static final String DifficultyUrl =  "https://discord.gg/aspectps";
    public static final String STARTGUIDE = "https://discord.gg/aspectps";
    public static final String PRICEGUIDE = "https://discord.gg/aspectps";
    public static final String SLAYERGUIDE = "https://discord.gg/aspectps";
    public static final long tempMuteInterval = 86400000;
    public static final int BaseImplingExpMultiplier = 2;
    /**
     * Shop Buy Limit (at one time)
     */
    public static final int Shop_Buy_Limit = 25000;
    public static final int Spec_Restore_Cooldown = 180000; // in milliseconds (180000 = 3 seconds * 60 * 1000)
    public static final int Vote_Announcer = 9; // 1,2,3,4,5,6,7,8,9 = 9 total.
    public static final int massMessageInterval = 180000; // in milliseconds (180000 = 3 seconds * 60 * 1000)
    public static final int charcterBackupInterval = 3600000;
    public static final int charcterSavingInterval = 15 * 60000;
    public static final int playerCharacterListCapacity = 5000; // was 1000
    public static final int npcCharacterListCapacity = 50000; // was 2027
    /**
     * The game port
     */
    /**
     * The game version
     */
    public static final int GAME_UID = 23; // don't change
    public static final boolean BCRYPT_HASH_PASSWORDS = false;
    public static final int BCRYPT_ROUNDS = Integer.parseInt("04"); // add a 0 for numbers less than 10. IE: 04, 05, 06,
    /**
     * The maximum amount of players that can be logged in on a single game
     * sequence.
     */
    public static final int LOGIN_THRESHOLD = 100;
    /**
     * The maximum amount of players that can be logged in on a single game
     * sequence.
     */
    public static final int LOGOUT_THRESHOLD = 100;
    /**
     * The maximum amount of players who can receive rewards on a single game
     * sequence.
     */
    public static final int VOTE_REWARDING_THRESHOLD = 15;
    // 07, 08, 09, 10, 11, etc.
    /**
     * The maximum amount of connections that can be active at a time, or in other
     * words how many clients can be logged in at once per connection. (0 is counted
     * too)
     */
    public static final int CONNECTION_AMOUNT = 3;
    /**
     * The throttle interval for incoming connections accepted by the
     * {@link ConnectionHandler}.
     */
    public static final long CONNECTION_INTERVAL = 1000;
    /**
     * The number of seconds before a connection becomes idle.
     */
    public static final int IDLE_TIME = 15;
    /**
     * The keys used for encryption on login
     */
    // REGENERATE RSA
    /*
     * This is the server, so in your PrivateKeys.txt Copy the ONDEMAND_MODULUS's
     * value to RSA_MODULUS below. Copy the ONDEMAND_EXPONENT's value to
     * RSA_EXPONENT below.
     */
    public static final BigInteger RSA_MODULUS = new BigInteger(
            "133567728213741143816509511422128583057676855627752897223206244773295600712883732719562506843823211218750380752578336050348277757629131584859245078421579140186623018332242256409998547043484697935288906462270420300277547466511098999079857947706507159245894090452949369807517421080349147184146818764010463810313");
    public static final BigInteger RSA_EXPONENT = new BigInteger(
            "18741914165335055900279559135112904920859916754700636935846996764197725623017208692633120419546183840695004370061345168668122774297839297715269507929335208512554570607386848426474068608268296375734276959109513059016659117858269240413485990150621744581036704243015567064352654789565136769391797590390726828977");
    /**
     * The maximum amount of messages that can be decoded in one sequence.
     */
    public static final int DECODE_LIMIT = 50;
    /**
     * GAME
     **/

    public static final int[] MASSACRE_ITEMS = {4587, 20051, 13634, 13632, 11842, 11868, 14525, 13734, 10828, 1704,
            15365, 15363, 7462, 3842};
    /**
     * Processing the engine
     */
    public static final int ENGINE_PROCESSING_CYCLE_RATE = 600;// 200;
    public static final int GAME_PROCESSING_CYCLE_RATE = 600;
    /**
     * The default position
     */
    public static final Position DEFAULT_POSITION = new Position(2076, 4456, 0);//3093, 3506
    public static final Position STARTER = new Position(3037, 10288, 0);//3093, 3506
    public static final Position CORP_CORDS = new Position(2900, 4384);
    public static final Position HOME_CORDS = new Position(2076, 4456, 0);//3093, 3506
    public static final Position OLDHOME_CORDS = new Position(2654, 3998, 0);
    public static final Position EDGE_CORDS = new Position(3086, 3488, 0);
    public static final Position TRIO_CORDS = new Position(3025, 5231, 0);
    public static final Position KFC_CORDS = new Position(2606, 4774, 4);
    public static final Position TRADE_CORDS = new Position(3164, 3485, 0);
    public static final Position CHILL_CORDS = new Position(3816, 2829, 0);
    public static final Position MEMBER_ZONE = new Position(2851, 3348);
    public static final Position SUPER_ZONE = new Position(1664, 5695);
    public static final Position EXTREME_ZONE = new Position(2791, 3096);
    public static final Position SUPER_ZONE_NPC = new Position(2827, 2866, 8);
    public static final Position EXTREME_ZONE_NPC = new Position(2827, 2866, 12);
    public static final Position DEVILSPAWN = new Position(2958, 9487, 0);
    public static final Position LORDS = new Position(2989, 9483, 0);
    public static final Position DEMON = new Position(2330, 3888, 0);
    public static final Position DRAGON = new Position(2377, 3886, 0);
    public static final Position BEAST = new Position(1698, 5600, 0);
    public static final Position HULK = new Position(3486, 3623, 0);
    public static final Position LEO = new Position(2708, 4752, 0);
    public static final Position KING = new Position(1625, 5601, 0);
    public static final Position PREDATOR = new Position(2901, 3617, 0);
    public static final Position BULWARK = new Position(2413, 3523, 0);
    public static final Position TRAIN = new Position(2517, 2521, 0);
    public static final Position EVENT = new Position(2731, 3463, 0);
    public static final Position PENG = new Position(3041, 9543, 0);
    public static final Position CYAN = new Position(2399, 3488, 0);
    public static final Position REVS = new Position(3650, 3485, 0);
    public static final Position CMINI = new Position(2582, 2565, 0);
    public static final Position GWD = new Position(2527, 2652, 0);
    public static final Position CORP = new Position(2900, 4384, 0);
    public static final int[] hweenIds2016 = {9922, 9921, 22036, 22037, 22038, 22039, 22040};
    public static final Position PORTALS = new Position(3192, 9828, 0);
    public static final int MAX_STARTERS_PER_IP = 3;
    public static final Item nullItem = new Item(-1, 0);
    /**
     * Untradeable items Items which cannot be traded or staked
     */

    public static final int[] UNTRADEABLE_ITEMS = {


    };
    /**
     * Unsellable items Items which cannot be sold to shops
     */
    public static final int UNSELLABLE_ITEMS[] = new int[]{995
    };
    public static final int ATTACK_TAB = 0, SKILLS_TAB = 1, QUESTS_TAB = 2, ACHIEVEMENT_TAB = 15, INVENTORY_TAB = 3,
            EQUIPMENT_TAB = 4, PRAYER_TAB = 5, MAGIC_TAB = 6,

    SUMMONING_TAB = 13, FRIEND_TAB = 8, IGNORE_TAB = 9, CLAN_CHAT_TAB = 10, LOGOUT = 14, OPTIONS_TAB = 11,
            EMOTES_TAB = 12, STAFF_TAB = 7;
    public static int players = 0;
    public static boolean DOUBLEDR = false;
    public static boolean Halloween = false;
    public static boolean Christmas2016 = false;
    public static boolean newYear2017 = false;
    public static boolean FridayThe13th = false;



    public static boolean LOG_CHAT = true;
    public static boolean LOG_NPCDROPS = true;
    public static boolean LOG_TRADE = true;
    public static boolean LOG_DUEL = true;
    public static boolean LOG_COMMANDS = true;
    public static boolean LOG_KILLS = true;
    public static boolean LOG_LOGINS = true;
    public static boolean LOG_LOGINSWIP = true;
    public static boolean LOG_BONDS = true;
    public static boolean LOG_SPINSWIP = true;
    public static boolean LOG_POS = true;
    public static boolean LOG_PICKUPS = true;
    public static boolean LOG_DROPPED = true;
    public static boolean LOG_DONATIONS = true;
    public static boolean LOG_CLAN = true;

}
